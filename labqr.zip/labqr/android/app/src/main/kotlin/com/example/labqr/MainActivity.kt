package com.example.labqr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
