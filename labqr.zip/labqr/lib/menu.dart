import 'dart:io';

import 'package:barcode_scan2/model/model.dart';
import 'package:barcode_scan2/platform_wrapper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:image_picker/image_picker.dart';

class Menu extends StatefulWidget {
  const Menu({super.key});

  @override
  State<Menu> createState() => _MenuState();
}

class _MenuState extends State<Menu> with TickerProviderStateMixin {
  late final TabController _tabcontroller;
  final ImagePicker _picker = ImagePicker();
  XFile? image;
  var result = "";
  int i = 0;
  int c = 0;
  int s = 0;

  List<Tab> mytab = [
    const Tab(
      icon: Icon(Icons.qr_code_2),
      text: "SCAN QR",
    ),
    const Tab(
      icon: Icon(Icons.account_balance),
      text: "SHOW",
    ),
  ];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _tabcontroller = TabController(length: mytab.length, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          "TabBar Sample",
          style: TextStyle(color: Colors.white),
        ),
        bottom: TabBar(
          controller: _tabcontroller,
          tabs: mytab,
        ),
      ),
      body: TabBarView(
        controller: _tabcontroller,
        children: [
          Container(
            color: Colors.green[100],
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      filePicker();
                      c++;
                    },
                    child: const Text("CAMERA"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      filePicker2();
                      i++;
                    },
                    child: const Text("GALLARY"),
                  ),
                  image == null
                      ? const Text("image Here")
                      : Image.file(
                          File(image!.path),
                          width: 250,
                        )
                ],
              ),
            ),
          ),
          Container(
            color: Colors.pink[200],
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("USE CAMERA $c",
                      style: const TextStyle(
                          fontSize: 32,
                          color: Colors.blue,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(
                    height: 30,
                  ),
                  Text("USE GALLORY $i",
                      style: const TextStyle(
                          fontSize: 32,
                          color: Colors.deepOrange,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(
                    height: 30,
                  ),
                  Text("USE SCAN $s",
                      style: const TextStyle(
                          fontSize: 32,
                          color: Colors.red,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(
                    height: 30,
                  ),
                  ElevatedButton(
                      onPressed: _ResetResult, child: const Text("Clear"))
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          _scanQR();
          s++;
        },
        label: Text("Scan\n $result"),
        icon: const Icon(Icons.qr_code_2),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  void filePicker() async {
    final XFile? selectImage =
        await _picker.pickImage(source: ImageSource.camera);
    setState(() {
      image = selectImage;
    });
  }

  void filePicker2() async {
    final XFile? selectImage =
        await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      image = selectImage;
    });
  }

  Future _scanQR() async {
    try {
      ScanResult qrResult = await BarcodeScanner.scan();
      setState(() {
        result = qrResult.rawContent;
      });
    } on PlatformException catch (e) {
      if (e.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          result = "Camera permission was denied";
        });
      } else {
        setState(() {
          result = "Unknown an Error $e";
        });
      }
    } on FormatException {
      setState(() {
        result = "You pressed the back button";
      });
    } catch (e) {
      setState(() {
        result = "Error Something $e";
      });
    }
  }

  void _ResetResult() async {
    setState(() {
      i = 0;
      c = 0;
      s = 0;
    });
  }
}
