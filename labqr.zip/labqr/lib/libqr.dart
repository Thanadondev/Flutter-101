import 'dart:io';

import 'package:barcode_scan2/barcode_scan2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:image_picker/image_picker.dart';

class LabQR extends StatefulWidget {
  const LabQR({super.key});

  @override
  State<LabQR> createState() => _LabQRState();
}

class _LabQRState extends State<LabQR> {
  final ImagePicker _picker = ImagePicker();
  XFile? image;
  var result = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Image and Scan QR"),
      ),
      body: SafeArea(
          child: Center(
        child: Column(children: [
          ElevatedButton(
            onPressed: () {
              filePicker();
            },
            child: const Text("CAMERA"),
          ),
          ElevatedButton(
            onPressed: () {
              filePicker2();
            },
            child: const Text("GALLARY"),
          ),
          const SizedBox(
            height: 20,
          ),
          image == null
              ? const Text("image Here")
              : Image.file(
                  File(image!.path),
                  width: 250,
                )
        ]),
      )),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          _scanQR();
        },
        label: Text("Scan\n $result"),
        icon: const Icon(Icons.qr_code_2),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  void filePicker() async {
    final XFile? selectImage =
        await _picker.pickImage(source: ImageSource.camera);
    setState(() {
      image = selectImage;
    });
  }

  void filePicker2() async {
    final XFile? selectImage =
        await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      image = selectImage;
    });
  }

  Future _scanQR() async {
    try {
      ScanResult qrResult = await BarcodeScanner.scan();
      setState(() {
        result = qrResult.rawContent;
      });
    } on PlatformException catch (e) {
      if (e.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          result = "Camera permission was denied";
        });
      } else {
        setState(() {
          result = "Unknown an Error $e";
        });
      }
    } on FormatException {
      setState(() {
        result = "You pressed the back button";
      });
    } catch (e) {
      setState(() {
        result = "Error Something $e";
      });
    }
  }
}
