import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:db_flutter/book.dart';
import 'package:db_flutter/db.dart';

class Db2 extends StatefulWidget {
  const Db2({Key? key}) : super(key: key);

  @override
  State<Db2> createState() => _Db2State();
}

class _Db2State extends State<Db2> {
  List<Map<String, dynamic>> mybooks = [];
  TextEditingController nameController = TextEditingController();
  TextEditingController priceController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DB 2"),
      ),
      body: Column(
        children: [
          SizedBox(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    showAddDialog();
                  },
                  child: Text("NEW BOOK"),
                ),
                ElevatedButton(
                  onPressed: () {
                    clearAll();
                  },
                  child: Text("CLEAR ALL"),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 250,
            child: SingleChildScrollView(child: buildlist()),
          )
        ],
      ),
    );
  }

  Widget buildlist() {
    return Column(
        children: mybooks
            .map((json) => Dismissible(
                onDismissed: (direction) {
                  todel(json["id"]);
                },
                key: Key(json["id"].toString()),
                child: Card(
                  child: ListTile(
                    leading: const Icon(Icons.data_object),
                    title: Text("${json["id"]} : ${json["name"]}"),
                    subtitle: Text("${json["price"]}"),
                    trailing: SizedBox(
                      width: 100,
                      height: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            onPressed: () {
                              showEditDialog(json);
                            },
                            icon: const Icon(Icons.edit),
                          ),
                          IconButton(
                            onPressed: () {
                              todel(json["id"]);
                            },
                            icon: const Icon(Icons.delete),
                          ),
                        ],
                      ),
                    ),
                  ),
                )))
            .toList());
  }

  void showAddDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Add New Book"),
          content: Column(
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: "Book Name"),
              ),
              TextField(
                controller: priceController,
                decoration: InputDecoration(labelText: "Book Price"),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                addBook();
              },
              child: Text("Add"),
            ),
          ],
        );
      },
    );
  }

  void showEditDialog(Map<String, dynamic> book) {
    nameController.text = book["name"];
    priceController.text = book["price"].toString();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Edit Book"),
          content: Column(
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: "Book Name"),
              ),
              TextField(
                controller: priceController,
                decoration: InputDecoration(labelText: "Book Price"),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                editBook(book["id"]);
              },
              child: Text("Save"),
            ),
          ],
        );
      },
    );
  }

  void addBook() async {
    DB db = DB.instance;
    Book book = Book(
      name: nameController.text,
      price: int.parse(priceController.text),
      id: 1,
    );
    Map<String, dynamic> row = book.toJson();
    row.remove("id");
    db.insert(row);
    mybooks = await db.queryAll();
    setState(() {});
  }

  void todel(int id) async {
    DB db = DB.instance;
    db.delete(id);
    mybooks = await db.queryAll();
    setState(() {});
  }

  void editBook(int id) async {
    DB db = DB.instance;
    Book book = Book(
        id: id,
        name: nameController.text,
        price: int.parse(priceController.text));
    Map<String, dynamic> row = book.toJson();
    db.update(id, row);
    mybooks = await db.queryAll();
    setState(() {});
  }

  void clearAll() async {
    DB db = DB.instance;
    await db.deleteAll();
    mybooks = await db.queryAll();
    setState(() {});
  }
}
