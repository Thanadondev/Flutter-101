import 'package:db_flutter/book.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class DB_test extends StatefulWidget {
  const DB_test({super.key});

  @override
  State<DB_test> createState() => _DB_testState();
}

class _DB_testState extends State<DB_test> {
  String text = "DB EX#1\n";

  List<Map<String, dynamic>> mybooks = [
    {"id": 1, "name": "HTML AND CSS", "price": 150},
    {"id": 2, "name": "Flutter", "price": 250},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("DB EX")),
      body: Column(
        children: [
          Text(text),
          ElevatedButton(
            onPressed: () {
              loaddata();
              setState(() {});
            },
            child: const Text("load data"),
          ),
          ElevatedButton(
            onPressed: () {
              readdata();
              setState(() {});
            },
            child: const Text("Read Data"),
          ),
          Column(
            children: [
              SizedBox(
                height: 300,
                child: SingleChildScrollView(child: buildlist()),
              ),
            ],
          )
        ],
      ),
    );
  }

  void loaddata() {
    text += "${mybooks[0]["name"]}";
  }

  void readdata() {
    List<Book> book = mybooks.map((json) => Book.fromJson(json)).toList();
    text += "${book[1].name}";
  }

  Widget buildlist() {
    return Column(
        children: mybooks
            .map((json) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.data_object),
                    title: Text("${json["id"]} : ${json["name"]}"),
                    subtitle: Text("${json["price"]}"),
                    trailing: SizedBox(
                      // color: Colors.amber,
                      width: 100,
                      height: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.edit),
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.delete),
                          ),
                        ],
                      ),
                    ),
                  ),
                ))
            .toList());
  }
}
