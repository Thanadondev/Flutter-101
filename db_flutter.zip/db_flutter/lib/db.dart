import 'dart:async';
import 'dart:io';
import 'package:db_flutter/book.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DB {
  static const dbname = "Mydb.db";
  static const dbversion = 1;
  static const tablename = "book";
  static const columnId = "id";
  static const columnName = "name";
  static const columnPrice = "price";

  DB._privateConstructor();
  static final DB instance = DB._privateConstructor();

  static Database? _database;

  factory DB() {
    return instance;
  }

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }

    _database = await _initDataBase();
    return _database!;
  }

  _initDataBase() async {
    Directory documentDir = await getApplicationDocumentsDirectory();
    String path = join(documentDir.path, dbname);
    return await openDatabase(path, version: dbversion, onCreate: _OnCreate);
  }

  Future _OnCreate(Database db, int version) async {
    await db.execute('''
      Create table $tablename(
        $columnId INTEGER PRIMARY KEY AUTOINCREMENT,
        $columnName TEXT NOT NULL, 
        $columnPrice INTEGER NOT NULL
      )
      ''');
  }

  Future<int> insert(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(tablename, row);
  }

  Future<List<Map<String, dynamic>>> queryAll() async {
    Database db = await instance.database;
    return await db.query(tablename);
  }

  Future<int> delete(int id) async {
    Database db = await instance.database;
    return await db.delete(
      tablename,
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }

  Future<int> update(int id, Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.update(
      tablename,
      row,
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteAll() async {
    Database db = await instance.database;

    await db.delete(tablename);
    await db.execute('DELETE FROM SQLITE_SEQUENCE WHERE NAME = ?', [tablename]);
    await db.execute('DROP TABLE IF EXISTS $tablename');
    await _OnCreate(db, dbversion);

    return 1;
  }
}
